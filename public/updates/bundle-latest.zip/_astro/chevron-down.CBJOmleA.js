import{c as o}from"./createLucideIcon.Br-Do1eh.js";const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],e=o("chevron-down",n);export{e as C};
