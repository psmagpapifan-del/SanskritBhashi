const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_astro/web.CnnAmluZ.js","_astro/index.D8gQjEOS.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./preload-helper.CVfkMyKi.js";import{r as o}from"./index.D8gQjEOS.js";const i=o("Preferences",{web:()=>r(()=>import("./web.CnnAmluZ.js"),__vite__mapDeps([0,1])).then(e=>new e.PreferencesWeb)});export{i as Preferences};
